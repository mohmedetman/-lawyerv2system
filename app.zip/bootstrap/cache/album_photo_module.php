<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AlbumPhoto\\Providers\\AlbumPhotoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AlbumPhoto\\Providers\\AlbumPhotoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);