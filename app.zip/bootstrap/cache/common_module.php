<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Common\\Providers\\CommonServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Common\\Providers\\CommonServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);