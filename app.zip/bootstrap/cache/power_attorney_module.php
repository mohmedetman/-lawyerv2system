<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PowerAttorney\\Providers\\PowerAttorneyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PowerAttorney\\Providers\\PowerAttorneyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);