<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Front\\Providers\\FrontServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Front\\Providers\\FrontServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);