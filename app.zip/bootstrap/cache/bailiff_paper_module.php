<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\BailiffPaper\\Providers\\BailiffPaperServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\BailiffPaper\\Providers\\BailiffPaperServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);