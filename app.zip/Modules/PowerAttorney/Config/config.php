<?php

return [
    'name' => 'PowerAttorney',
];
