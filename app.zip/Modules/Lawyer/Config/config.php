<?php

return [
    'name' => 'Lawyer',
];
