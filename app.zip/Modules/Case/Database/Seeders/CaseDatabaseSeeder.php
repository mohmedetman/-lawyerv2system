<?php

namespace Modules\Case\Database\Seeders;

use Illuminate\Database\Seeder;

class CaseDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
