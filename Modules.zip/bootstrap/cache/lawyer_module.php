<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Lawyer\\Providers\\LawyerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Lawyer\\Providers\\LawyerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);