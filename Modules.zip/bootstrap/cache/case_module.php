<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Case\\Providers\\CaseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Case\\Providers\\CaseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);