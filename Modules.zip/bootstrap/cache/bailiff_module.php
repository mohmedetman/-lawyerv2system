<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Bailiff\\Providers\\BailiffServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Bailiff\\Providers\\BailiffServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);