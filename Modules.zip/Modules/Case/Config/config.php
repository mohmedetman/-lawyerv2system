<?php

return [
    'name' => 'Case',
];
