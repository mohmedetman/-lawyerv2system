<?php

namespace Modules\Lawyer\Database\Seeders;

use Illuminate\Database\Seeder;

class LawyerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
