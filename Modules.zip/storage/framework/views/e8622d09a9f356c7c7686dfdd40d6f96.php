<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('case.name'); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('case::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\-lawyerv2system\Modules/Case\Resources/views/index.blade.php ENDPATH**/ ?>